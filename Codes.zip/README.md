# Google Cloud Documentation RAG System

This project processes Google Cloud documentation and creates a RAG (Retrieval-Augmented Generation) system for answering questions about Google Cloud services.

## Components

### Document Processing Pipeline

The document processing pipeline consists of:

1. A Cloud Function triggered when new documents are uploaded to Cloud Storage
2. Document AI OCR processor to extract text from documents
3. Text chunking for RAG preparation
4. Vector embedding generation using Vertex AI Text Embedding models
5. Automatic Q&A pair generation for each chunk
6. Category and keyword extraction
7. Storage of all data in BigQuery

### RAG Query System

The RAG query system provides:

1. Vector similarity search to find relevant document chunks
2. Gemini Pro LLM for answer generation
3. A simple API for integration with other systems
4. A web interface for testing and demonstration

## Getting Started

### Prerequisites

- Google Cloud Project with the following APIs enabled:
  - Cloud Functions
  - Document AI
  - Vertex AI
  - BigQuery
  - Cloud Storage
- Python 3.9+
- Google Cloud CLI installed and configured

### Deployment

1. Clone this repository
2. Update environment variables in `deploy_rag.sh`
3. Run the deployment script:

```bash
chmod +x deploy_rag.sh
./deploy_rag.sh --project=YOUR_PROJECT_ID --region=YOUR_REGION
```

### Using the RAG System

#### Web Interface

1. Start the web server:

```bash
export BQ_DATASET=your_dataset
export BQ_RAG_TABLE=rag_chunks
python rag_server.py
```

2. Open a browser to `http://localhost:8080`
3. Ask questions about Google Cloud

#### Command Line Interface

```bash
export BQ_DATASET=your_dataset
export BQ_RAG_TABLE=rag_chunks
python rag_query.py "How do I create a Cloud Storage bucket?"
```

## Architecture

```
┌───────────────┐     ┌───────────────┐     ┌───────────────┐
│  Document     │     │  Document AI   │     │   Vertex AI   │
│  Uploaded to  │────▶│  OCR Text      │────▶│   Embedding   │
│  Cloud Storage│     │  Extraction    │     │   Generation  │
└───────────────┘     └───────────────┘     └───────────────┘
                                                     │
                                                     ▼
┌───────────────┐     ┌───────────────┐     ┌───────────────┐
│  RAG Query    │     │  BigQuery     │     │   Chunking &   │
│  Web Interface│◀───▶│  Storage &    │◀────│   Metadata     │
│               │     │  Retrieval    │     │   Extraction   │
└───────────────┘     └───────────────┘     └───────────────┘
```

## Table Schema

The RAG system uses the following BigQuery schema:

| Column             | Type           | Description                                |
|--------------------|----------------|--------------------------------------------|
| `chunk_id`         | STRING         | Unique identifier for the chunk            |
| `document_path`    | STRING         | Path to the source document                |
| `event_id`         | STRING         | Processing event ID                        |
| `time_processed`   | TIMESTAMP      | When the chunk was processed               |
| `text_chunk`       | STRING         | The actual text content                    |
| `vector_embedding` | FLOAT64 ARRAY  | Vector embedding of the text               |
| `metadata`         | JSON           | Additional metadata about the chunk        |
| `questions`        | STRING ARRAY   | Sample questions this chunk can answer     |
| `answers`          | STRING ARRAY   | Answers to the sample questions            |
| `category`         | STRING         | Category or topic of the chunk             |
| `keywords`         | STRING ARRAY   | Important keywords from the chunk          |

## Customization

You can customize various aspects of the system:

- Chunk size and overlap in `main.py`
- Embedding and generation models in `rag_query.py`
- Query parameters in `rag_server.py`
- Web interface design in `rag_server.py`

## License

This project is licensed under the Apache License 2.0 - see the LICENSE file for details.